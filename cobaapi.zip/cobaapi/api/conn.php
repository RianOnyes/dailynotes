<?php
    $hostname = 'localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'cobaapidb';

    $conn = mysqli_connect($hostname, $dbUsername, $dbPassword, $dbName);
?>